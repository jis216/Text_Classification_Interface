# Lambda get all GitHub Contributions

Fetch all GitHub Contributions and save them to a json on S3.
